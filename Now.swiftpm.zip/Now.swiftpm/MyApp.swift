import SwiftUI

@main
struct MyApp: App {
    @StateObject private var persistence = Persistence.shared
    @StateObject private var userData = UserData()
    
    @AppStorage("isDarkMode") private var isDarkMode = true
    var body: some Scene {
        WindowGroup {
        HomeView()
                .preferredColorScheme(isDarkMode ? .dark : .light)
                .environment(\.managedObjectContext, persistence.container.viewContext)
                .environmentObject(userData)
        }
    }
}
